---
title: "Developer Environment Setup"
date: 2025-07-05
draft: false
weight: 2
---

## Prerequisites

| Tool | Version | Notes |
|------|---------|-------|
| **Node.js** | 20 LTS | Aligns with latest c2pa‑node bindings. |
| **pnpm** | ≥ 9 | Faster monorepo installs. |
| **React Native CLI** | 10+ | <https://reactnative.dev/docs/environment-setup> |
| **Xcode** | 16 | iOS 17 SDK for App Attest. |
| **Android Studio** | Iguana | Includes AGP 8 & NDK 26. |
| **Rust** | 1.78 | Compiles the C2PA core. |

### 1. Clone & bootstrap

```bash
git clone git@github.com:YourOrg/c2pa-mobile.git
cd c2pa-mobile
pnpm install
```

### 2. iOS certificates & provisioning

* Enroll in the **Apple Developer Program**.  
* Create an **App ID** with *App Attest* enabled.  
* Download the `.p8` key for **DeviceCheck v2**.

### 3. Android keystore

Use **Android Key Mint** with **StrongBox** (if present):

```bash
./gradlew keystore -Palias=signing_release
```

### 4. Postgres local

```bash
docker run --name c2pa-pg -e POSTGRES_PASSWORD=postgres -p 5432:5432 -d postgres:17
```

> **Tip:** add `init.sql` to seed roles & tables.

### 5. AWS Amplify back‑end

```bash
npm i -g @aws-amplify/cli
amplify init
amplify add auth
amplify add storage
amplify push
```

See the [AWS Amplify React Native guide](https://docs.aws.amazon.com/prescriptive-guidance/latest/patterns/build-a-serverless-react-native-mobile-app-by-using-aws-amplify.html).

