---
title: "4‑Week Sprint Plan"
date: 2025-07-05
draft: false
weight: 9
---

## Week 1 — Foundations

| Role | Tasks |
|------|-------|
| Backend | • POC Secure Enclave / StrongBox key gen<br>• Stand‑up Postgres via Docker Compose |
| Frontend | • Set up React Native repo<br>• Integrate camera preview |
| UI/UX | • Create Figma wireframes for capture & playback |
| QA | • Define acceptance criteria<br>• Set up Detox skeleton |

## Week 2 — Capture pipeline

| Role | Tasks |
|------|-------|
| Backend | • Lambda skeleton<br>• S3 bucket & IAM |
| Frontend | • Per‑frame hashing & chunker<br>• Swift/Kotlin bridge |
| UI/UX | • Design trust indicators & empty states |
| QA | • Unit tests for hashing<br>• Device matrix plan |

## Week 3 — Provenance & security

| Role | Tasks |
|------|-------|
| Backend | • OCSP stapling service<br>• Transparency log table |
| Frontend | • Embed manifests via `c2pa-node`<br>• Validate via `c2pa-js` |
| UI/UX | • Polish playback screen |
| QA | • Pen‑test revoked cert flow |

## Week 4 — Hardening & release

| Role | Tasks |
|------|-------|
| Backend | • RFC 3161 timestamp TSA<br>• Audit logging |
| Frontend | • App Store / Play Store configs |
| UI/UX | • Accessibility sweep |
| QA | • Full regression<br>• Store‑submission artifacts |

