---
title: "Solution Architecture"
date: 2025-07-05
draft: false
weight: 3
---

### High‑level components

1. **Mobile app (React Native)**  
   * C2PA capture & validation  
   * Offline cache  
   * JWT auth via **Amazon Cognito**

2. **Secure Element**  
   * Device‑bound ECDSA P‑256 key  
   * Attestation certificate chain

3. **API Gateway + Lambda**  
   * Ingest fMP4 chunks  
   * Finalise manifest, issue RFC 3161 timestamp  
   * Publish to **Transparency Log**

4. **PostgreSQL (RDS)**  
   * Clip & user metadata  
   * Revocation events

5. **S3 + CloudFront**  
   * Immutable clip storage  
   * Signed URLs

6. **Transparency log (Aurora Serverless)**  
   * Append‑only Merkle tree  
   * Public audit endpoint

---

### Data flow

1. Capture starts → Secure Enclave nonce.  
2. Frames hashed; per‑chunk manifest signed with *ephemeral* key.  
3. Chunk uploaded → Lambda verifies & stores.  
4. On “stop”, Lambda finalises parent manifest, stamps time.  
5. Clip hash committed to transparency log.  
6. Viewers fetch clip + manifest; validate via **c2pa‑js**.

---

### Threat mitigations

| Threat | Control |
|--------|---------|
| Screen replay | `UIScreen.isCaptured` (iOS) / `FLAG_SECURE` (Android) |
| Mid‑stream tamper | fMP4 segmentation + Merkle subtree |
| Key compromise | Per‑clip ephemerals + OCSP stapling |
| CA expiration | Cert & OCSP embedded in manifest |
| Log removal | Transparency log anchored in RDS snapshots |
