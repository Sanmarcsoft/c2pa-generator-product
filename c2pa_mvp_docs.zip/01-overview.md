---
title: "C2PA‑enabled Mobile Capture — MVP Overview"
date: 2025-07-05
draft: false
weight: 1
---

Welcome to the **4‑week MVP guide** for building a secure mobile video‑capture app with **C2PA v2.2**.

> **Audience:**  
> *Backend*, *Frontend*, *UI/UX* & *QA* engineers — one of each.  
> **Goal:** Release to Apple App Store & Google Play Store in four sprints.

---

## Quick links  

* 📜 **Specification 2.2** — <https://c2pa.org/specifications/specifications/2.2/index.html>  
* 🛠 **c2pa‑node** — <https://github.com/contentauth/c2pa-node>  
* 🛠 **c2pa‑js** — <https://github.com/contentauth/c2pa-js>  
* 🚀 **React Native docs** — <https://reactnative.dev/docs/environment-setup>

---

## Architecture snapshot

```mermaid
flowchart TD
    A[React Native UI] -->|native module| B(Bridge: Swift / Kotlin)
    B --> C[c2pa-node (Rust core)]
    C --> D[fMP4 + manifest]
    C -.--> E[Secure Enclave / StrongBox key]
    D -->|upload| F[API Gateway (AWS)]
    F --> G[PostgreSQL on RDS]
    F --> H[S3 clip storage]
```

---

## Week‑by‑week

| Week | Milestone | Owner |
|------|-----------|-------|
| 1 | Device attestation & key provisioning POC | Backend |
| 2 | Native camera pipeline + per‑frame hashing | Frontend |
| 3 | Embed C2PA manifest; OCSP stapling; bare‑bones UI | Frontend + UI/UX |
| 4 | End‑to‑end QA, CI/CD, store submission | QA + All |

See **09‑weekly-plan.md** for the fine‑grained tasks.

---

## Folder map

| Path | Description |
|------|-------------|
| `/content/overview` | This file |
| `/content/architecture` | System & data‑flow |
| `/content/setup` | Environment & onboarding |
| `/content/frontend` | React Native + C2PA integration |
| `/content/backend` | API, Postgres, AWS infra |
| `/content/ui-ux` | Design guidelines & Figma links |
| `/content/qa` | Test strategy & acceptance matrix |
| `/content/deployment` | iOS & Android store checklist |

Happy building! ✨
