---
title: "Frontend Guide (React Native)"
date: 2025-07-05
draft: false
weight: 4
---

## Module map

| Package | Purpose |
|---------|---------|
| `@c2pa/node` (native) | Embed & sign manifests |
| `c2pa-js` (WASM) | Validate & display |
| `react-native-camera` | High‑performance capture |
| `react-native-video` | Playback with C2PA overlay |
| `react-native-keychain` | Access Secure Enclave / StrongBox |

### Capture workflow

```typescript
import {{ C2paWriter }} from '@c2pa/node';
import {{ Camera }} from 'react-native-camera';

const writer = await C2paWriter.create({{
  keyLabel: 'ephemeral_clip_key',
  algorithm: 'ECDSA_P256_SHA256'
}});

const onFrame = async (frame: Uint8Array) => {{
  writer.hashFrame(frame);
  if (writer.shouldFlush()) {{
    await writer.flushChunk();
  }}
}};
```

### Native bridge tips

* **iOS** — Use `RCTBridgeModule` + `dispatch_queue_create` for hashing.  
* **Android** — `@ReactMethod(isBlockingSynchronousMethod = true)` to avoid JNI overhead.  
* Bind Swift/Kotlin tests in Detox for parity.

### Playback validation

```tsx
import {{ C2paReader }} from 'c2pa-js';

const validate = async (uri: string) => {{
  const reader = await C2paReader.create(uri);
  const status = await reader.validate();
  setStatus(status.ok ? 'Trusted' : 'Untrusted');
}};
```

> **Docs:** <https://opensource.contentauthenticity.org/docs/js-sdk/getting-started/overview>
