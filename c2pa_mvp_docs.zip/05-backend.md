---
title: "Backend & Infrastructure"
date: 2025-07-05
draft: false
weight: 5
---

## Stack

* **API Gateway** → **Lambda (Node 20)**  
* **RDS PostgreSQL 17**  
* **S3** (clip storage)  
* **CloudFront** (delivery)  
* **AWS Certificate Manager** (TLS)  
* **EventBridge** (revocation broadcasts)

### Database schema (simplified)

```sql
CREATE TABLE clips (
  id UUID PRIMARY KEY,
  owner UUID NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  manifest JSONB NOT NULL,
  ocsp_response BYTEA NOT NULL
);

CREATE TABLE transparency_log (
  seq BIGSERIAL PRIMARY KEY,
  clip_id UUID REFERENCES clips(id),
  merkle_root BYTEA NOT NULL,
  logged_at TIMESTAMPTZ DEFAULT now()
);
```

### Lambda flow

1. Verify JWT (Cognito).  
2. Parse chunk; run `c2pa-node` verify.  
3. Store fMP4 to S3 (`s3://clips/$id/$seq.mp4`).  
4. Insert manifest & OCSP into Postgres.  
5. Update Merkle accumulator; write log row.  
6. Return signed CloudFront URL.

### Revocation

* `DELETE /device/{id}` sets `revoked_at` in Postgres.  
* EventBridge rule publishes to SNS; app listens and blocks recorder.

