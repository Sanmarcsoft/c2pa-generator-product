---
title: "UI / UX Guidelines"
date: 2025-07-05
draft: false
weight: 6
---

### Principles

1. **Provenance first** — surface trust signals *inline* during capture & playback.  
2. **Fail‑loudly** — any validation warning → red banner + disable share.  
3. **Minimal latency** — use activity rings instead of spinner while hashing.  

### Capture screen wireframe

```
+-----------------------------------+
|  ● 00:12  |  Trusted 🔒           |
|-----------------------------------|
| (camera preview)                  |
|                                   |
|  Hash progress ▓▓▓▓▓░░            |
|  Depth map: active                |
|-----------------------------------|
| ⬤ Record / Stop | Gallery | ⚙︎    |
+-----------------------------------+
```

### Colour & typography

| Token | Value |
|-------|-------|
| `--color-trusted` | `#4ade80` (green‑500) |
| `--color-untrusted` | `#f87171` (red‑400) |
| Font | Inter 400 / 600 |

---

### Empty states

* Offline → grey badge “Offline (hashing only)”.  
* Screen‑capture detected → modal *“Screen recording blocked for secure capture.”*.

### Accessibility

* VoiceOver labels: “Trusted clip”, “Untrusted clip”.  
* Minimum tap target 48 × 48 dp.  
* Haptic feedback on validation change.

