---
title: "Deployment & App Store Checklist"
date: 2025-07-05
draft: false
weight: 8
---

## iOS / iPadOS

| Task | Detail |
|------|--------|
| App Attest v2 | Submit compliance doc to Apple review. |
| Privacy | Declare “Camera”, “Microphone”, “Local Network” usage. |
| Encryption export compliance | Tick *“Yes, but exempt”*. |

### Fastlane script

```ruby
lane :release do
  capture_screenshots
  build_app(scheme: "c2pa")
  upload_to_app_store
end
```

## Android

| Task | Detail |
|------|--------|
| Key Mint attestation | Upload JSON proof in Play Console “Data safety”. |
| Play Integrity API | Enable “Enforce” level. |
| Store listing | Link to **C2PA white‑paper** in privacy section. |

### Gradle action

```bash
./gradlew bundleRelease
gcloud firebase test android run --type robo --app build/output.apk
```

---

## Over‑the‑air updates

Use **Expo EAS Update** (or CodePush) with *code signing* enabled.

