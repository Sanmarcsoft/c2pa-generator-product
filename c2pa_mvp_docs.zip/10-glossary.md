---
title: "Glossary"
date: 2025-07-05
draft: false
weight: 10
---

| Term | Definition |
|------|------------|
| **C2PA** | *Coalition for Content Provenance & Authenticity* — open standard for cryptographic media provenance. |
| **Manifest** | Signed JSON‑LD data describing the history and trust info of a media asset. |
| **OCSP** | *Online Certificate Status Protocol* — real‑time certificate revocation check. |
| **RFC 3161** | Time‑Stamp Protocol standard. |
| **Secure Enclave / StrongBox** | Dedicated secure subsystems for key storage on iOS / Android. |
| **Transparency log** | Append‑only, publicly auditable Merkle tree of asset hashes. |

